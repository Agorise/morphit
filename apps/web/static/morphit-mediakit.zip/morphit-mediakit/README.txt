Morphit media kit
─────────────────

This bundle contains current brand assets and a public-facing claims
list for Morphit — a federated, non-custodial, no-KYC peer-to-peer
marketplace for fiat ↔ Bitcoin, Monero, BLURT, and USDT trades.

Source repo:  https://git.agorise.net/agorise/morphit
Project URL:  https://morphit.io  (one instance among many)
License:      AGPL-3.0

Contents
────────
  MORPHIT-BRAG-LIST.md       Current public-facing claims — what we
                              built, what we got right, what we are
                              still working on.  Every claim is
                              backed by code in the repo or honestly
                              disclosed as backlog.  Use as a
                              reference when writing about Morphit.

  logos/morphit-mark.svg     The standalone Morphit mark (no
                              wordmark).  Use when the surrounding
                              context already says "Morphit" or
                              when you want a square icon.

  logos/morphit-wordmark.svg The mark together with the "Morphit"
                              wordmark.  Use when the logo needs to
                              identify itself.

Usage notes
───────────
You're welcome to use the logos to talk about Morphit — link to
the project, write articles, give talks, build integrations, host
your own instance.  Please don't modify the logos to represent
something other than Morphit, or use them in a way that implies
official endorsement of an unrelated product or service.

The brag list reflects the state of the repo at the time this
zip was built.  For the absolute latest, see MORPHIT-BRAG-LIST.md
in the source repo.
