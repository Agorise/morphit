Morphit media kit
─────────────────

This bundle contains current brand assets and a public-facing claims
list for Morphit — a federated, non-custodial, no-KYC peer-to-peer
marketplace for fiat ↔ Bitcoin, Monero, BLURT, USDT, Bitcoin Cash,
Litecoin, and Dash trades.

Source repo:  https://git.agorise.net/agorise/morphit
Project URL:  https://morphit.io  (one instance among many)
License:      AGPL-3.0

Contents
────────
  MORPHIT-BRAG-LIST.md       Current public-facing claims — what we
                              built, what we got right, what we are
                              still working on.  Every claim is
                              backed by code in the repo or honestly
                              disclosed as backlog.  Use as a
                              reference when writing about Morphit.

  morphit-comparison.png     Feature-by-feature comparison of Morphit
                              against Bisq, Haveno/RetoSwap, OpenMonero,
                              and BasicSwap.  The same image Morphit
                              serves at https://<instance>/morphit-comparison.png
                              for blog and fediverse hot-linking — bundled
                              here so you have it offline.  Every claim is
                              traceable to source code or the competitor's
                              public docs; corrections welcome via Matrix
                              #agorise:matrix.org.

  logos/morphit-mark.svg     The standalone Morphit mark (no
                              wordmark).  Use when the surrounding
                              context already says "Morphit" or
                              when you want a square icon.

  logos/morphit-wordmark.svg The mark together with the "Morphit"
                              wordmark.  Use when the logo needs to
                              identify itself.

Usage notes
───────────
You're welcome to use the logos to talk about Morphit — link to
the project, write articles, give talks, build integrations, host
your own instance.  Please don't modify the logos to represent
something other than Morphit, or use them in a way that implies
official endorsement of an unrelated product or service.

The brag list reflects the state of the repo at the time this
zip was built.  For the absolute latest, see MORPHIT-BRAG-LIST.md
in the source repo.

Color standards
───────────────
The canonical Morphit palette, kept in sync with the site's
Tailwind config.  If the brand colors change, regenerating this
kit (scripts/build-mediakit.sh) updates these values too.

  Lime      #8EEF26
  Accent    #7FED2D
  Emerald   #00DA69
  Teal      #02A6B2
  Btn       #027C86
  Ink       #0B1220
  Paper     #FEFEFE

  Brand gradient:
    linear-gradient(90deg, #8EEF26 0%, #00DA69 50%, #02A6B2 100%)
