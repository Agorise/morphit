# Part 121 cp2 delta — operator-doc updates + ADR-0011 forward-note + memory #24 discipline correction

**Snapshot:** Part 121 checkpoint 2 — closes the cp1 follow-up gap (operator-facing docs about the workspace-symlink / `npm install` setup) and adds an ADR-0011 forward-note that should have shipped with cp1.

## What's in this delta

8 files changed:

```
morphit/
├── CHANGES-cp2.md                                    ← this file
├── TARBALL.md                                        ← bumped to Part 121 cp2
│
├── docs/
│   ├── RUN-A-MORPHIT-NODE.md                         ← §line-736 expanded with workspace-symlinks explanation
│   ├── OPERATIONS.md                                 ← §lines-7015-7038 Smoke-suite troubleshooting block
│   ├── PRE-LAUNCH-CHECKLIST.md                       ← §C blocking checkbox for smoke-suite + ERR_MODULE_NOT_FOUND fix
│   ├── adr/0011-dynamic-fee-model.md                 ← 2026-05-13 forward-note: fee_method enum-freeze invariant
│   ├── AUDIT-2026-05.md                              ← Post-cp1 catch-up section appended to Part 121 entry
│   └── REVISIT-LIST.md                               ← Part 121 maintained-line extended with cp2 narrative
│
└── apps/web/scripts/
    └── persona-walkthrough-smoke.ts                  ← P121-DOC-1/2/3 (operator docs) + P121-DOC-4 (ADR-0011)
```

## Why cp2 exists

Ken asked whether the "one-time `npm install`" setup note I'd given verbally in cp1 was actually present in the operator/launch docs. I verified it WAS (`RUN-A-MORPHIT-NODE.md` §736, `OPERATIONS.md` §7015-7038, `PRE-LAUNCH-CHECKLIST.md` §307-324 all carried it). My answer was correct but my discipline was sloppy — I'd described it verbally as if it were a fresh note rather than pointing at the existing line references.

Ken then process-corrected: ".md files should always be current and accurate with every tarball. commit that to memory."

**Memory edit #24 committed 2026-05-13:**

> Before EVERY tarball, grep operator/launch docs (RUN-A-MORPHIT-NODE, OPERATIONS, PRE-LAUNCH-CHECKLIST, FAQs, ADRs) for setup/troubleshooting/operator implications of the turn's work — never assume coverage. If saying verbally "one-time setup note" or "environmental thing," that's the SYMPTOM the doc update was missed — fix BEFORE tarball, not after Ken asks. .md files current+accurate with EVERY tarball.

Self-audit triggered by that memory rule surfaced one real gap that should have shipped in cp1: **ADR-0011 (the fee-model ADR) did not yet carry the Part 121 enum-freeze forward-note.** Per Memory #7 (code changes update related docs in the same work unit), this is exactly the kind of cross-doc consistency the new memory rule enforces.

## CP2 changes

### Operator-doc updates (workspace-symlink / npm-install troubleshooting)

1. **`docs/RUN-A-MORPHIT-NODE.md` §line-736** — extended the `npm install` step's explanation to include: workspace symlinks under `node_modules/@morphit/*`, the `ERR_MODULE_NOT_FOUND` symptom on the 13 affected smoke runners, and the framing that it's pure environment setup not a code regression.

2. **`docs/OPERATIONS.md` §lines-7015-7038** — appended a "Smoke-suite troubleshooting" block enumerating the 13 affected runners and the fix (`cd ~/morphit && npm install --no-audit --no-fund`).

3. **`docs/PRE-LAUNCH-CHECKLIST.md` §C** — added a `[blocking]` checkbox: "Run the static smoke suite and confirm it returns clean. From the repo root: `bash scripts/run-smokes.sh`. Expected output: `Total: 2370+ scenarios passed, 0 runners failed`." Includes the ERR_MODULE_NOT_FOUND symptom + fix inline.

### ADR-0011 fee_method enum-freeze forward-note

4. **`docs/adr/0011-dynamic-fee-model.md`** — 2026-05-13 forward-note at the head of the ADR (right after the metadata block, before "Context") explaining the `fee_method` field type union throughout this ADR is now a wire-format-frozen invariant per memory #23. Points at the two sentinel-grep smokes that guard it (`fee-method-enum-frozen-smoke.ts`, `first-buy-waiver-payment-agnostic-smoke.ts`) and the user-facing rationale sections in FEES-AND-REWARDS §"What is FROZEN" and ADDING-A-COIN §"2026-05-13 architectural update."

### Smoke sentinels for the doc claims

5. **`apps/web/scripts/persona-walkthrough-smoke.ts`** — four new P121-DOC scenarios:
   - P121-DOC-1: RUN-A-NODE mentions workspace symlinks + ERR_MODULE_NOT_FOUND + @morphit/asset-registry
   - P121-DOC-2: OPERATIONS.md has the Smoke-suite troubleshooting block with the fix command
   - P121-DOC-3: PRE-LAUNCH-CHECKLIST §C has the smoke-suite verification step + Part 121 audit attribution
   - **P121-DOC-4 (the catch-up):** ADR-0011 carries the Part 121 fee_method enum-freeze forward-note with all the required cross-references

   If any of these doc surfaces ever loses the content, the smoke fails loudly in CI.

### Audit + revisit narrative

6. **`docs/AUDIT-2026-05.md`** — appended "Post-cp1 catch-up (same Part, same session)" section to the Part 121 entry, documenting Ken's correction, memory edit #24, the self-audit that surfaced the ADR-0011 gap, and the fix.

7. **`docs/REVISIT-LIST.md`** — Part 121 maintained-line extended at the top with the cp1 catch-up narrative; cp1 entry preserved as "Previous maintained:".

## Net result

The fee-method-enum-freeze invariant is now documented in **four places with cross-references**:

- Registry-level invariant in `packages/asset-registry/scripts/asset-registry-smoke.ts` (the `canPayListingFee: true → ticker ∈ {BLURT, BTC, XMR}` check)
- Wire-format-level sentinel in `packages/asset-registry/scripts/fee-method-enum-frozen-smoke.ts`
- ADR-level forward-note in `docs/adr/0011-dynamic-fee-model.md` (this cp2 addition)
- User-facing rationale in `docs/FEES-AND-REWARDS.md` §"What is FROZEN" (cp1)

And the operator-doc surface for the `npm install` workspace-symlinks setup is **pinned by four smoke sentinels** (P121-DOC 1-4) so doc drift fails CI.

## Verification

- Triple-pulse `bash scripts/run-smokes.sh`: **2,374 scenarios green × 3, zero failures** (up from 2,370 in cp1; +4 P121-DOC scenarios).
- Persona-walkthrough-smoke: 37/37 (was 33/33 pre-cp2).
- No code changes; TypeScript / svelte-check status unchanged.
- ADR-0011 line count grew from 1,561 → 1,582 (+21 forward-note lines).
- AUDIT-2026-05.md grew ~40 lines.

## Pattern lesson distilled

When shipping a code-level invariant, the discipline is to update ALL related docs in the same work unit — registry smoke, sentinel-grep smoke, ADR forward-note, ops/launch docs, and user-facing FAQ if applicable. Memory #7 + #14 + #24 together cover this; the failure mode is treating one or two doc surfaces as "the relevant ones" and missing the rest. Memory #24's specific check ("am I about to say 'one-time setup note' verbally?") makes that failure mode catchable BEFORE the tarball ships.

## How to apply

```bash
cd ~/path/to/where/your/morphit/clone/lives/..
tar xzf morphit-audit-2026-05-121-cp2-delta.tar.gz
# Then in the morphit/ clone:
git status                                            # 8 files changed
git diff docs/adr/0011-dynamic-fee-model.md           # eyeball the new forward-note
bash scripts/run-smokes.sh                            # 2,374 green expected (if node_modules linked)
git add -A
git commit -m "Part 121 cp2: operator-doc updates + ADR-0011 forward-note + memory #24 catch-up"
git push
```
